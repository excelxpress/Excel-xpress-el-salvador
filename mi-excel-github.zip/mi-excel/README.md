# Mi Excel - Hoja de Cálculo Web

Aplicación de hoja de cálculo tipo Excel hecha 100% en HTML + JavaScript.  
Funciona offline, se puede instalar en Android como app y permite **varios libros** + **compartir**.

## Características

- **Varios libros** (como archivos independientes de Excel)
- Varias hojas dentro de cada libro
- Fórmulas: `SUM`, `AVERAGE`, `MAX`, `MIN`, `COUNT`, `IF`, `ROUND`, `ABS`, `POWER`, `SQRT`, `CONCAT`, `LEN`, `LEFT`, `RIGHT`, `TODAY`, `NOW`
- Formato: negrita, colores, moneda ($), porcentaje (%)
- Insertar / eliminar filas y columnas
- Ordenar columnas (A-Z / Z-A)
- Gráfico de barras
- Congelar paneles
- Guardado automático
- Exportar a CSV
- **Compartir con enlace** (edición o solo lectura)

## Cómo usar los Libros

1. Arriba a la izquierda verás un selector de libros.
2. Haz clic en el botón **📚 Libros** para:
   - Crear un nuevo libro
   - Renombrar
   - Eliminar
3. Cada libro es independiente (tiene sus propias hojas y datos).

## Cómo publicarlo en GitHub Pages

1. Crea un repositorio nuevo en GitHub (ej: `mi-excel`)
2. Sube los archivos:
   - `index.html`
   - `README.md`
3. Ve a **Settings → Pages**
4. Source: rama `main` + carpeta `/ (root)`
5. En 1-2 minutos tendrás tu URL:

```
https://tu-usuario.github.io/mi-excel/
```

## Cómo compartir

1. Abre el libro que quieres compartir
2. Haz clic en **🔗 Compartir**
3. Elige permiso (editar o solo ver)
4. Genera el enlace y envíalo

> Nota: El compartir es una captura (snapshot), no es edición en tiempo real.

## Atajos

| Tecla        | Acción              |
|--------------|---------------------|
| `Enter`      | Confirmar y bajar   |
| `Tab`        | Ir a la derecha     |
| `Escape`     | Cancelar edición    |
| `Delete`     | Borrar celda        |
| `Ctrl + Z`   | Deshacer            |

## Licencia

Uso libre.
